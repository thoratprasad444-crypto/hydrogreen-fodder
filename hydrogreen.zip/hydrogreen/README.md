# HydroGreen Fodder – ऑनलाईन ऑर्डर वेबसाइट (EDP प्रोजेक्ट)

ग्राहक ऑर्डर देतो → पेमेंट करतो → ऑर्डर ट्रॅक करतो → प्रत्येक स्टेजला मोबाईलवर मेसेज येतो.

## चालवायचे कसे
1. Node.js (18 किंवा नवीन) install करा: https://nodejs.org
2. या फोल्डरमध्ये टर्मिनल उघडा:
   ```
   npm install
   copy .env.example .env      (Mac/Linux: cp .env.example .env)
   npm start
   ```
3. ब्राउझरमध्ये उघडा:
   - ग्राहक वेबसाइट: http://localhost:3000
   - Admin पॅनल: http://localhost:3000/admin  (पासवर्ड: `.env` मधील ADMIN_PASSWORD)

`.env` मध्ये काहीही न बदलता पूर्ण flow चालतो (Demo payment + मेसेज टर्मिनलमध्ये दिसतात) – कॉलेज डेमोसाठी हे पुरेसे आहे.

## खरे पेमेंट (Razorpay)
1. razorpay.com वर खाते उघडा → Test Mode → Settings → API Keys
2. `.env` मध्ये `RAZORPAY_KEY_ID` आणि `RAZORPAY_KEY_SECRET` भरा
3. सर्व्हर पुन्हा सुरू करा. Test UPI/कार्डने पेमेंट चालते. खरे पैसे घेण्यासाठी Live keys लागतात (KYC आवश्यक).

## खरे मेसेज
`.env` मध्ये `MSG_PROVIDER` निवडा:
- `twilio_whatsapp` – Twilio WhatsApp sandbox (फुकट टेस्ट; ग्राहकाने आधी sandbox join करावे लागते)
- `twilio_sms` – Twilio SMS
- `fast2sms` – Fast2SMS (भारतात SMS; त्यांच्या खात्यातील नियम लागू)
- `console` – फक्त टर्मिनलमध्ये दाखवते

मेसेज पाठवण्यात अडचण आली तरी ऑर्डर सेव्ह होते. Admin → Message log मध्ये result दिसतो, आणि प्रत्येक ऑर्डरसमोर "WhatsApp" बटण आहे – ते तुमच्या फोनवर तयार मेसेज उघडते (API शिवाय, फुकट).

## Flow
- ऑर्डर: product, संख्या, नाव, मोबाईल, गाव, पत्ता → पहिल्या ऑर्डरवर 10% सूट (मोबाईल नंबरवरून)
- पेमेंट: ऑनलाईन (Razorpay, सर्व्हरवर signature verify) किंवा डिलिव्हरीवर रोख
- ट्रॅकिंग: ऑर्डर कोड (HG-1001) + मोबाईल नंबर
- Admin: status बदला (Confirmed → Packed → Out for delivery → Delivered / Cancelled) – प्रत्येक बदलावर ग्राहकाला मेसेज
- ऑनलाईन पेमेंट अर्धवट राहिले तर ग्राहक "ऑर्डर ट्रॅक करा" मधून पुन्हा पेमेंट करू शकतो

## इंटरनेटवर टाकताना (Deploy)
Render / Railway सारख्या सेवेवर टाका आणि `.env` मध्ये `BASE_URL` तुमच्या वेबसाइटचा पत्ता ठेवा (मेसेजमधील ट्रॅक लिंकसाठी). ADMIN_PASSWORD नक्की बदला. डेटा `hydrogreen.db` फाईलमध्ये राहतो – फुकट hosting वर ही फाईल पुसली जाऊ शकते, म्हणून persistent disk वापरा.

## फाईल्स
- `server.js` – सर्व्हर, डेटाबेस (SQLite), पेमेंट, मेसेज
- `public/index.html` – ग्राहक पान (मराठी/English)
- `public/admin.html` – Admin पॅनल
