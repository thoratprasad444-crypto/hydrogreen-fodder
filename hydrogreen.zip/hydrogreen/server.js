require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const Database = require('better-sqlite3');

const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const RZP_ID = process.env.RAZORPAY_KEY_ID || '';
const RZP_SECRET = process.env.RAZORPAY_KEY_SECRET || '';
const DEMO_PAYMENT = !(RZP_ID && RZP_SECRET);
const MSG_PROVIDER = process.env.MSG_PROVIDER || 'console';
const BUSINESS_PHONE = '+91 83295 71103';

const PRODUCTS = {
  loose:   { price: 10,  loose: true },   // per kg
  pack5:   { price: 45 },                 // 5 kg pack
  weekly:  { price: 250 },                // 30 kg weekly plan
  monthly: { price: 900 }                 // 120 kg monthly plan
};
const STATUSES = ['placed', 'confirmed', 'packed', 'out_for_delivery', 'delivered', 'cancelled'];

// ---------- database ----------
const db = new Database(path.join(__dirname, 'hydrogreen.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE, name TEXT, phone TEXT, village TEXT, address TEXT,
  product TEXT, qty INTEGER, subtotal INTEGER, discount INTEGER, total INTEGER,
  pay_method TEXT, pay_status TEXT, rzp_order_id TEXT, rzp_payment_id TEXT,
  status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, status TEXT,
  at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, phone TEXT, body TEXT,
  provider TEXT, result TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

// ---------- helpers ----------
const normPhone = p => String(p || '').replace(/\D/g, '').slice(-10);
const validPhone = p => /^[6-9]\d{9}$/.test(p);
const getByCode = code => db.prepare('SELECT * FROM orders WHERE code=?').get(String(code || '').trim().toUpperCase());

function quote(productKey, qty, phone) {
  const p = PRODUCTS[productKey];
  if (!p) throw new Error('Invalid product');
  qty = parseInt(qty, 10);
  const [min, max] = p.loose ? [5, 500] : [1, 20];
  if (!(qty >= min && qty <= max)) throw new Error(`Quantity must be between ${min} and ${max}`);
  const subtotal = p.price * qty;
  let discount = 0;
  if (phone) {
    const prior = db.prepare("SELECT COUNT(*) c FROM orders WHERE phone=? AND pay_status IN ('paid','cod') AND status!='cancelled'").get(phone).c;
    if (prior === 0) discount = Math.round(subtotal * 0.10);
  }
  return { qty, subtotal, discount, total: subtotal - discount };
}

function messageText(o, kind) {
  const track = `${BASE_URL}/?track=${o.code}`;
  const m = {
    placed_cod: `HydroGreen Fodder: तुमची ऑर्डर ${o.code} मिळाली. डिलिव्हरीच्या वेळी ₹${o.total} द्या. ट्रॅक करा: ${track}`,
    paid: `HydroGreen Fodder: ₹${o.total} चे पेमेंट मिळाले. ऑर्डर ${o.code} नोंदवली आहे. ट्रॅक करा: ${track}`,
    confirmed: `HydroGreen Fodder: ऑर्डर ${o.code} कन्फर्म झाली. तुमचा ताजा चारा तयार केला जात आहे.`,
    packed: `HydroGreen Fodder: ऑर्डर ${o.code} पॅक झाली आहे.`,
    out_for_delivery: `HydroGreen Fodder: ऑर्डर ${o.code} डिलिव्हरीसाठी निघाली आहे.`,
    delivered: `HydroGreen Fodder: ऑर्डर ${o.code} डिलिव्हर झाली. धन्यवाद! पुन्हा ऑर्डरसाठी ${BUSINESS_PHONE}.`,
    cancelled: `HydroGreen Fodder: ऑर्डर ${o.code} रद्द झाली. माहितीसाठी ${BUSINESS_PHONE}.`
  };
  return m[kind] || '';
}

async function sendMessage(order, body) {
  let result = 'ok';
  try {
    if (MSG_PROVIDER === 'twilio_whatsapp' || MSG_PROVIDER === 'twilio_sms') {
      const wa = MSG_PROVIDER === 'twilio_whatsapp';
      const from = String(process.env.TWILIO_FROM || '').replace('whatsapp:', '');
      const params = new URLSearchParams({
        To: (wa ? 'whatsapp:' : '') + '+91' + order.phone,
        From: (wa ? 'whatsapp:' : '') + from,
        Body: body
      });
      const auth = Buffer.from(`${process.env.TWILIO_SID}:${process.env.TWILIO_TOKEN}`).toString('base64');
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_SID}/Messages.json`, {
        method: 'POST',
        headers: { Authorization: 'Basic ' + auth, 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params
      });
      if (!r.ok) throw new Error(await r.text());
    } else if (MSG_PROVIDER === 'fast2sms') {
      const r = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: { authorization: process.env.FAST2SMS_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ route: 'q', message: body, language: 'unicode', numbers: order.phone })
      });
      const j = await r.json();
      if (!j.return) throw new Error(JSON.stringify(j));
    } else {
      console.log(`[MESSAGE -> ${order.phone}] ${body}`);
    }
  } catch (e) {
    result = 'failed: ' + String(e.message).slice(0, 300);
    console.error('Message failed:', result);
  }
  db.prepare('INSERT INTO messages(order_id,phone,body,provider,result) VALUES(?,?,?,?,?)')
    .run(order.id, order.phone, body, MSG_PROVIDER, result);
}

function logStatus(orderId, status) {
  db.prepare('INSERT INTO history(order_id,status) VALUES(?,?)').run(orderId, status);
}

async function setStatus(order, status, kind) {
  db.prepare('UPDATE orders SET status=? WHERE id=?').run(status, order.id);
  logStatus(order.id, status);
  const fresh = db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
  await sendMessage(fresh, messageText(fresh, kind || status));
  return fresh;
}

async function rzpCreate(order) {
  const auth = Buffer.from(`${RZP_ID}:${RZP_SECRET}`).toString('base64');
  const r = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + auth },
    body: JSON.stringify({ amount: order.total * 100, currency: 'INR', receipt: order.code })
  });
  if (!r.ok) throw new Error('Razorpay: ' + (await r.text()));
  return (await r.json()).id;
}

async function paymentInfo(order) {
  const base = { order: publicOrder(order), amount: order.total * 100 };
  if (DEMO_PAYMENT) return { ...base, payment: 'demo' };
  let rid = order.rzp_order_id;
  if (!rid) {
    rid = await rzpCreate(order);
    db.prepare('UPDATE orders SET rzp_order_id=? WHERE id=?').run(rid, order.id);
  }
  return { ...base, payment: 'razorpay', key: RZP_ID, rzpOrderId: rid };
}

async function markPaid(order, paymentId) {
  if (order.pay_status === 'paid') return order;
  db.prepare("UPDATE orders SET pay_status='paid', rzp_payment_id=? WHERE id=?").run(paymentId, order.id);
  return setStatus(db.prepare('SELECT * FROM orders WHERE id=?').get(order.id), 'placed', 'paid');
}

const publicOrder = o => ({
  code: o.code, name: o.name, village: o.village, product: o.product, qty: o.qty,
  subtotal: o.subtotal, discount: o.discount, total: o.total,
  pay_method: o.pay_method, pay_status: o.pay_status, status: o.status, created_at: o.created_at
});

// ---------- app ----------
const app = express();
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

const wrap = fn => (req, res) => fn(req, res).catch(e => res.status(400).json({ error: e.message }));

app.get('/api/config', (req, res) => {
  res.json({ demoPayment: DEMO_PAYMENT, phone: BUSINESS_PHONE,
    products: Object.entries(PRODUCTS).map(([key, p]) => ({ key, price: p.price, loose: !!p.loose })) });
});

app.get('/api/quote', wrap(async (req, res) => {
  res.json(quote(req.query.product, req.query.qty, normPhone(req.query.phone)));
}));

app.post('/api/orders', wrap(async (req, res) => {
  const b = req.body || {};
  const phone = normPhone(b.phone);
  const name = String(b.name || '').trim().slice(0, 80);
  const village = String(b.village || '').trim().slice(0, 80);
  const address = String(b.address || '').trim().slice(0, 300);
  const method = b.pay_method === 'cod' ? 'cod' : 'online';
  if (name.length < 2) throw new Error('Name is required');
  if (!validPhone(phone)) throw new Error('Enter a valid 10-digit mobile number');
  if (village.length < 2 || address.length < 5) throw new Error('Village and delivery address are required');
  const q = quote(b.product, b.qty, phone);

  const info = db.prepare(`INSERT INTO orders(code,name,phone,village,address,product,qty,subtotal,discount,total,pay_method,pay_status,status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run('TMP' + crypto.randomBytes(4).toString('hex'), name, phone, village, address, b.product, q.qty,
      q.subtotal, q.discount, q.total, method, method === 'cod' ? 'cod' : 'pending',
      method === 'cod' ? 'placed' : 'awaiting_payment');
  const code = 'HG-' + (1000 + Number(info.lastInsertRowid));
  db.prepare('UPDATE orders SET code=? WHERE id=?').run(code, info.lastInsertRowid);
  let order = db.prepare('SELECT * FROM orders WHERE id=?').get(info.lastInsertRowid);
  logStatus(order.id, order.status);

  if (method === 'cod') {
    await sendMessage(order, messageText(order, 'placed_cod'));
    return res.json({ payment: 'cod', order: publicOrder(order) });
  }
  res.json(await paymentInfo(order));
}));

// retry payment for an order that is still awaiting payment
app.post('/api/orders/pay-again', wrap(async (req, res) => {
  const o = getByCode(req.body.code);
  if (!o || o.phone !== normPhone(req.body.phone)) throw new Error('Order not found');
  if (o.pay_status !== 'pending') throw new Error('This order does not need payment');
  res.json(await paymentInfo(o));
}));

app.post('/api/payments/verify', wrap(async (req, res) => {
  if (DEMO_PAYMENT) throw new Error('Razorpay is not configured');
  const { code, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  const o = getByCode(code);
  if (!o || o.rzp_order_id !== razorpay_order_id) throw new Error('Order not found');
  const expected = crypto.createHmac('sha256', RZP_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  const given = String(razorpay_signature || '');
  const ok = expected.length === given.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(given));
  if (!ok) throw new Error('Payment verification failed');
  res.json({ order: publicOrder(await markPaid(o, razorpay_payment_id)) });
}));

// demo payment (only when Razorpay keys are NOT set) - for classroom demo
app.post('/api/payments/demo', wrap(async (req, res) => {
  if (!DEMO_PAYMENT) throw new Error('Demo payment is disabled');
  const o = getByCode(req.body.code);
  if (!o || o.phone !== normPhone(req.body.phone)) throw new Error('Order not found');
  res.json({ order: publicOrder(await markPaid(o, 'demo_' + crypto.randomBytes(5).toString('hex'))) });
}));

app.get('/api/track', wrap(async (req, res) => {
  const o = getByCode(req.query.code);
  if (!o || o.phone !== normPhone(req.query.phone)) throw new Error('Order not found. Check the order code and mobile number.');
  const history = db.prepare('SELECT status, at FROM history WHERE order_id=? ORDER BY id').all(o.id);
  res.json({ order: publicOrder(o), history });
}));

// ---------- admin ----------
function admin(req, res, next) {
  const key = String(req.headers['x-admin-key'] || '');
  const a = Buffer.from(key), b = Buffer.from(ADMIN_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Wrong password' });
  next();
}

app.get('/api/admin/orders', admin, (req, res) => {
  const rows = db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 300').all();
  res.json(rows.map(o => ({ ...o, wa_text: messageText(o, o.status === 'awaiting_payment' ? 'placed_cod' : o.status) })));
});

app.post('/api/admin/orders/:id/status', admin, wrap(async (req, res) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
  if (!o) throw new Error('Order not found');
  if (!STATUSES.includes(req.body.status)) throw new Error('Invalid status');
  if (o.status === 'awaiting_payment') throw new Error('Waiting for customer payment');
  let updated = await setStatus(o, req.body.status);
  if (req.body.status === 'delivered' && updated.pay_method === 'cod' && updated.pay_status === 'cod') {
    db.prepare("UPDATE orders SET pay_status='paid' WHERE id=?").run(o.id); // cash collected on delivery
    updated = db.prepare('SELECT * FROM orders WHERE id=?').get(o.id);
  }
  res.json(updated);
}));

app.get('/api/admin/messages', admin, (req, res) => {
  res.json(db.prepare(`SELECT m.*, o.code FROM messages m LEFT JOIN orders o ON o.id=m.order_id ORDER BY m.id DESC LIMIT 100`).all());
});

app.listen(PORT, () => {
  console.log(`HydroGreen Fodder running: ${BASE_URL}`);
  console.log(`Admin panel: ${BASE_URL}/admin`);
  console.log(`Payment: ${DEMO_PAYMENT ? 'DEMO mode (no Razorpay keys)' : 'Razorpay'} | Messages: ${MSG_PROVIDER}`);
});
